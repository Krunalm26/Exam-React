// Action creators for rooms

export const fetchRoomsRequest = () => ({
    type: 'FETCH_ROOMS_REQUEST',
  });
  
  export const fetchRoomsSuccess = (rooms) => ({
    type: 'FETCH_ROOMS_SUCCESS',
    payload: rooms,
  });
  
  export const fetchRoomsFailure = (error) => ({
    type: 'FETCH_ROOMS_FAILURE',
    payload: error,
  });
  
  // Thunk action for fetching rooms
  export const fetchRooms = () => {
    return async (dispatch) => {
      dispatch(fetchRoomsRequest());
      try {
        const response = await fetch('https://api.example.com/rooms'); // Replace with your API URL
        const data = await response.json();
        dispatch(fetchRoomsSuccess(data));
      } catch (error) {
        dispatch(fetchRoomsFailure(error.message));
      }
    };
  };
  