// Initial state for reservations
const initialState = {
    reservations: [],
    loading: false,
    error: null,
  };
  
  // Reducer to manage reservation data
  const reservationReducer = (state = initialState, action) => {
    switch (action.type) {
      case 'CREATE_RESERVATION_REQUEST':
        return { ...state, loading: true };
      case 'CREATE_RESERVATION_SUCCESS':
        return { ...state, loading: false, reservations: [...state.reservations, action.payload] };
      case 'CREATE_RESERVATION_FAILURE':
        return { ...state, loading: false, error: action.payload };
      default:
        return state;
    }
  };
  
  export default reservationReducer;
  