 import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import RoomList from './components/Roomlist';
import Navbar from './components/Navbar';
import ReservationForm from './components/ReservationForm';
import RoomDetails from './components/Roomdetails';


const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<RoomList />} />
        <Route path="/reservation" element={<ReservationForm />} />
        <Route path="/room/:id" element={<RoomDetails />} />
      </Routes>
    </Router>
  );
};

export default App;

  
 