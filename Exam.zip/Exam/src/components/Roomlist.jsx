import React from "react";
import "./RoomList.css";

const RoomList = () => {
  const rooms = [
    { id: 1, name: "Single Room", price: "$100/night", description: "A cozy room for one person." },
    { id: 2, name: "Double Room", price: "$150/night", description: "Perfect for two guests." },
    { id: 3, name: "Suite", price: "$250/night", description: "Luxury suite with premium amenities." },
    { id: 4, name: "Family Room", price: "$200/night", description: "Spacious room for the whole family." },
  ];

  return (
    <div className="roomlist-container">
      <h2 className="roomlist-heading">Available Rooms</h2>
      <div className="roomlist-grid">
        {rooms.map((room) => (
          <div key={room.id} className="room-card">
            <h3 className="room-name">{room.name}</h3>
            <p className="room-price">{room.price}</p>
            <p className="room-description">{room.description}</p>
            <button className="room-button">Book Now</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RoomList;
