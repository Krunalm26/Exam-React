import React from 'react';
import './RoomDetails.css';

const RoomDetails = ({ room }) => {
  if (!room) {
    return <div className="room-details-container">Room not found.</div>;
  }

  return (
    <div className="room-details-container">
      <h2 className="room-details-heading">{room.name}</h2>
      <div className="room-details-grid">
        <div className="room-image">
          <img src={room.image} alt={room.name} />
        </div>
        <div className="room-info">
          <p className="room-price">{room.price}</p>
          <p className="room-description">{room.description}</p>
          <p className="room-size">Size: {room.size} sqm</p>
          <p className="room-bed">Beds: {room.beds} {room.beds > 1 ? 'beds' : 'bed'}</p>
          <ul className="room-amenities">
            <h4>Amenities:</h4>
            {room.amenities.map((amenity, index) => (
              <li key={index}>{amenity}</li>
            ))}
          </ul>
          <button className="room-book-button">Book Now</button>
        </div>
      </div>
    </div>
  );
};

export default RoomDetails;
